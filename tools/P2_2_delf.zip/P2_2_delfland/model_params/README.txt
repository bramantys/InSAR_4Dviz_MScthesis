==================================================================================================

	SPAMS10 Delfland: Soil motion parameters to model relative surface elevation changes

==================================================================================================
Authors: Y.A. Lumban-Gaol, P.N. Conroy, S. van Diepen, F. van Leijen, R.F. Hanssen
Department of Geoscience and Remote Sensing, Faculty of Civil Engineering and Geosciences,
Delft University of Technology
Corresponding author: R.F. Hanssen

Contact Information:
r.f.hanssen@tudelft.nl
Delft University of Technology - Faculty of Civil Engineering and Geosciences
Stevinweg 1
2628 CN Delft
The Netherlands


==================================================================================================

	General Introduction

==================================================================================================
This dataset contains SPAMS10 parameters over the Delfland region in the Netherlands.
DOI: https://doi.org/10.4121/c8646561-5475-4e23-bd90-3b1a3375ac7c

The dataset is stored in a parquet data format. In addition, the JSON file provides the metadata
related to this dataset. The GitHub repository (https://github.com/TUDelftGeodesy/pyspams)
provides an example script on how to read and model relative surface elevation changes using
SPAMS parameters provided in this SPAMS10 dataset.

References:
[1] Conroy, P., S. A. N. van Diepen and R. F. Hanssen, "SPAMS: A new empirical model for soft
soil surface displacement based on meteorological input data", Geoderma, vol. 440, pp. 1-4, 2023,
https://doi.org/10.1016/j.geoderma.2023.116699.


==================================================================================================

	Description of the data in this dataset

==================================================================================================
The parquet data contains the 10 parameters and other variables:
pnt_id 	= parcel ID
pnt_gid = group ID
pnt_lat = latitude coordinate in WGS84
pnt_lon = longitude coordinate in WGS84
xP 		= the scaling factor of precipitation
xE 		= the scaling factor of evapotranspiration
xI 		= the irreversible subsidence rate (mm/day)
tau 	= the integration time (days)
var_xP	= the variance of xP
var_xE	= the variance of xE
var_xI	= the variance of xI
cov_xPxE= the covariance between xP and xE
cox_xPxI= the covariance between xP and xI
cov_xExI= the covariance between xE and xI
meteo_id= the closest KNMI station ID
soilcode= soiltype based on the basisregistratie ondergrond

The JSON file contains its metadata:
project_name		= the region of the dataset
spams10_filename	= the parquet data file name
metadata_filename	= the JSON file name
meteo_data_source	= source of meteorological data
meteo_id			= list of meteorological stations nearby
insar_start_date	= start InSAR period used during SPAMS10 parameter estimation
insar_end_date		= last InSAR period used during SPAMS10 parameter estimation
